import React, {Component} from 'react';
import './styles/App.scss';
import {Route, Switch} from "react-router-dom";
import Intro from "./components/Intro";
import AdminLayout from "./components/AdminLayout";
import 'bootstrap/dist/css/bootstrap.min.css';
import AdminDashboard from "./components/AdminDashboard";

class App extends Component {
    render() {
        return (
            <div className={'App'}>
                <Switch>
                    <Route path={'/'} exact>
                        <Intro />
                    </Route>
                    <Route path={'/admin'} exact>
                        <AdminLayout />
                    </Route>
                    <Route path={'/admin/dashboard'} exact>
                        <AdminDashboard />
                    </Route>
                </Switch>
            </div>
        );
    }
}

export default App;