import React, {Component} from 'react';
import {Button, Modal} from "react-bootstrap";
import axios from 'axios'

class CurrentOrder extends Component {
    state = {
        show: false
    };
    showModal = event => {
        event.preventDefault();
        this.setState({show: true})
    };
    closeModal = () => {
        this.setState({show: false})
    };
    deleteOrder = async () => {
        try {
            await axios.delete(`https://solotareva-ba042.firebaseio.com/orders/${this.props.id}.json`)
        } catch (e) {
            console.log(e)
        }
        window.location.reload();
    };
    render() {
        return (
            <div className={'CurrentOrder'}>

                <Modal show={this.state.show} onHide={this.closeModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Обратная связь</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>Вы уверены, что хотите изменить заявку?</Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" onClick={this.closeModal}>
                            Да
                        </Button>
                        <Button variant="secondary" onClick={this.closeModal}>
                            Закрыть
                        </Button>
                    </Modal.Footer>
                </Modal>

                <div className="card">
                    <div className="card-body">
                        <div className="text">
                            <p><span>Имя: </span> {this.props.name}</p>
                            <p><span>Email: </span> {this.props.email}</p>
                            <p><span>Телефон: </span> {this.props.phone}</p>
                            <p><span>Описание заказа: </span> {this.props.description}</p>
                        </div>
                        <div className="buttons">
                            <Button variant={'danger'} onClick={this.deleteOrder}>Удалить</Button>
                            <Button variant={'primary'} onClick={this.showModal}>Редактировать</Button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CurrentOrder;