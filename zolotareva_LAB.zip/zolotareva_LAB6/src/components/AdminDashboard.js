import React, {Component} from 'react';
import CurrentOrder from "./CurrentOrder";
import axios from 'axios'

class AdminDashboard extends Component {
    state = {
        orders: []
    };
    async componentDidMount() {
        try {
            const response = await axios.get('https://solotareva-ba042.firebaseio.com/orders.json');
            const orders = Object.entries(response.data).map((order) => {
                return {
                    orderId: order[0],
                    orderData: order[1]
                }
            });
            this.setState({orders})
        } catch (e) {
            console.log(e)
        }
    }
    render() {
        return (
            <div className={'AdminDashboard'}>
                <div className="card">
                    <h3>Заказы пользователей</h3>
                    <div className="card-body">
                        {this.state.orders.map((order, index) => {
                            return (
                                <CurrentOrder
                                    key={index+order}
                                    name={order.orderData.name}
                                    phone={order.orderData.phone}
                                    email={order.orderData.email}
                                    description={order.orderData.description}
                                    id={order.orderId}
                                />
                            )
                        })}
                    </div>
                </div>
            </div>
        );
    }
}

export default AdminDashboard;