import React, {Component} from 'react';
import {Button, Form} from "react-bootstrap";
import {NavLink} from "react-router-dom";

class AdminLayout extends Component {
    state = {
        adminEmail: 'admin@admin.com',
        adminPassword: '123456',
        email: '',
        password: ''
    };
    setEmail = event => {
        this.setState({email: event.target.value})
    };
    setPassword = event => {
        this.setState({password: event.target.value})
    };
    render() {
        const validate =
            this.state.email === ''
        ||  this.state.password === ''
        ||  this.state.password !== this.state.adminPassword
        ||  this.state.email !== this.state.adminEmail;
        return (
            <div className={'AdminLayout'}>
                <h3>Привет, Admin</h3>
                <p>Для администрирования, войдите, пожалуйста</p>
                <Form>
                    <Form.Group controlId="email">
                        <Form.Label>Введите email</Form.Label>
                        <Form.Control type="email" placeholder="Введите email" onChange={this.setEmail} />
                    </Form.Group>

                    <Form.Group controlId="password">
                        <Form.Label>Введите пароль</Form.Label>
                        <Form.Control type="password" placeholder="Введите пароль" onChange={this.setPassword} />
                    </Form.Group>
                    {validate ?
                        <Button variant="primary" type="submit" disabled>Войти в систему</Button> :
                        <NavLink to={'/admin/dashboard'}>
                            <Button variant="primary" type="submit">Войти в систему</Button>
                        </NavLink>
                    }
                </Form>
            </div>
        );
    }
}

export default AdminLayout;