import React, {Component} from 'react';
import {Button, Form, Modal} from "react-bootstrap";
import axios from 'axios'

class Intro extends Component {
    state = {
        show: false,
        name: '',
        email: '',
        phone: '',
        description: ''
    };
    setName = event => {
        this.setState({name: event.target.value})
    };
    setPhone = event => {
        this.setState({phone: event.target.value})
    };
    setEmail = event => {
        this.setState({email: event.target.value})
    };
    setDescription = event => {
        this.setState({description: event.target.value})
    };
    closeModal = () => {
        this.setState({show: false})
    };
    sendData = async event => {
        event.preventDefault();
        try {
            await axios.post('https://solotareva-ba042.firebaseio.com/orders.json', {
                name: this.state.name,
                email: this.state.email,
                phone: this.state.phone,
                description: this.state.description,
            })
        } catch (e) {
            console.log(e)
        }
        this.setState({show: true})
    };
    render() {
        const validate =
            this.state.name === ''
        ||  this.state.email === ''
        ||  this.state.phone === ''
        ||  this.state.description === '';
        return (
            <div className={'Intro'}>

                <Modal show={this.state.show} onHide={this.closeModal}>
                    <Modal.Header closeButton>
                        <Modal.Title>Обратная связь</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>Спасибо! Ваша заявка успешно прнията, ожидайте звонка или сообщения на ваш почтовый ящик</Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={this.closeModal}>
                            Закрыть
                        </Button>
                    </Modal.Footer>
                </Modal>

                <div className="Intro__info">
                    <h1>Студия профессионального дизайна</h1>
                    <p>Вы приятно удивитесь, когда мы притворим все ваши замечательные идеи в жизнь!</p>
                </div>
                <div className="Intro__form">
                    <h4>Подать заявку на создание персонального дизайна</h4>
                    <Form>
                        <Form.Group controlId="name">
                            <Form.Label>Ваше имя</Form.Label>
                            <Form.Control type="text" placeholder="Введите имя" onChange={this.setName} />
                        </Form.Group>

                        <Form.Group controlId="email">
                            <Form.Label>Ваш E-mail</Form.Label>
                            <Form.Control type="email" placeholder="Введите email" onChange={this.setEmail} />
                        </Form.Group>

                        <Form.Group controlId="phone">
                            <Form.Label>Ваш Телефон</Form.Label>
                            <Form.Control type="tel" placeholder="Введите телефон" onChange={this.setPhone} />
                        </Form.Group>

                        <Form.Group controlId="description">
                            <Form.Label>Описание пожеланий</Form.Label>
                            <Form.Control as="textarea" rows="3" onChange={this.setDescription} />
                        </Form.Group>
                        <small>Заполните все поля, чтобы продолжить</small>
                        <br/>
                        {validate ?
                            <Button variant="primary" type="submit" disabled>Отправить заявку</Button> :
                            <Button variant="primary" type="submit" onClick={this.sendData}>Отправить заявку</Button>
                        }
                    </Form>
                </div>
            </div>
        );
    }
}

export default Intro;